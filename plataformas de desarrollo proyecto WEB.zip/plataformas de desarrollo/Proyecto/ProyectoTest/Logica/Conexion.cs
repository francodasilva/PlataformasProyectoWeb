﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoTest.Logica
{
    public class Conexion
    {
        public static string CN = "Data Source=.;Initial Catalog=DB_CARRITO;Integrated Security=True";
    }
}